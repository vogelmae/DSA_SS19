package de.unistuttgart.vis.dsass2019.ex01.p3;


public class Queue<T> implements IQueue<T> {
	

}
