package de.unistuttgart.vis.dsass2019.ex00.p1;

public class Calculator implements ICalculator {


}