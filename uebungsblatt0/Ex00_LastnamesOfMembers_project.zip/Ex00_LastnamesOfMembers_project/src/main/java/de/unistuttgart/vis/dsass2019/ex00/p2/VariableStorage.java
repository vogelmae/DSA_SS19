package de.unistuttgart.vis.dsass2019.ex00.p2;

public class VariableStorage<T> implements IVariableStorage<T> {

	

}
